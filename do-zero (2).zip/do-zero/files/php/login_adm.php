<?php 
    include('db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
    
    if(isset($_POST['submit'])){
        $cpf = $_POST['cpf'];
        $senha = $_POST['pass'];
        
        $sql = "SELECT * FROM adm WHERE cpf = '$cpf' AND senha = '$senha'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) == 1) {
            $_SESSION['username'] = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
            header('Location: /./do-zero/files/php/preview.php');
            exit;
        }
    }
    
    
    mysqli_close($conn);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrativo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 60px;
            margin: 0px;
            padding: 0px;
        }
        .navbar-custom {
            background-color: #007bff; 
            padding: 0.5rem 1rem;
        }
        .navbar-custom .navbar-brand {
            color: white;
        }
        .login-window {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: auto;
            width: 100%;
            max-width: 360px;
        }
        .container {
            padding: 0 15px; 
        }
        h3 {
            margin-bottom: 20px; 
            text-align: center;
            color: #007bff;
        }
        label {
            font-weight: bold;
            color: #555;
        }
        .form-control {
            margin-bottom: 10px;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">Sistema de Avaliação</a>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="login-window">
            <h3>Login Administrativo</h3>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <div class="mb-3">
                    <label for="cpf">CPF:</label>
                    <input type="text" id="cpf" name="cpf" class="form-control" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" minlength="14" maxlength="14" placeholder="123.456.789-00" required>
                </div>
                <div class="mb-3">
                    <label for="pass">Senha:</label>
                    <input type="password" id="pass" name="pass" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary" name="submit">Entrar</button>
            </form>    
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
    document.getElementById('cpf').addEventListener('input', function(e) {
        var cpf = e.target.value.replace(/\D/g, ''); 
        cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); 
        cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); 
        cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); 
        e.target.value = cpf; 
    });

    document.getElementById('telefone').addEventListener('input', function(e) {
        var tel = e.target.value.replace(/\D/g, ''); 
        tel = tel.replace(/(\d{2})(\d)/, '($1) $2'); 
        tel = tel.replace(/(\d{4,5})(\d{4})$/, '$1-$2'); 
        e.target.value = tel; 
    });
</script>

<!-- <?php 
    if (isset($_POST['submit'])){
        $_SESSION['username'] = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
        $cpf = $_POST['cpf'];
        $senha = $_POST['pass'];

        $sql = "SELECT * FROM adm WHERE cpf = '$cpf' AND senha = '$senha'";
        $result = mysqli_query($conn, $sql);


        // header('Location: /./FRAMEWORK/do-zero/files/php/avaliacao.php');
        header('Location: /./do-zero/files/php/avaliacao.php');
    }
?> -->