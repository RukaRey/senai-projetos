<?php 
    include('db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 40px;
            color: #333;
            margin: 0px;
            padding: 0px;
        }
        h3 {
            color: #0056b3;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-label {
            font-weight: 600;
            color: #444;
        }
        .form-check-label {
            margin-right: 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            width: 100%;
            padding: 10px;
            font-size: 18px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .navbar-custom {
            background-color: #007bff;
            padding: 0.5rem 1rem;
        }
        .navbar-custom .navbar-brand,
        .navbar-custom .nav-link {
            color: white;
        }
        .navbar-custom .nav-link:hover {
            color: #ccc;
        }
        textarea {
            resize: none;
        }
        .login-window {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: auto;
            width: 90%;
            max-width: 600px;
        }
        footer {
            text-align: center;
            padding: 10px 0;
            font-size: 0.8rem;
            background-color: #f8f9fa;
            bottom: 0;
            width: 100%;
        }
    </style>      
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">Sistema de Avaliação</a>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>Avaliação do Serviço</h3>
        <div class="login-window">
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                <div>
                    <label for="" class="form-label">1) O serviço foi concluído no prazo?</label><br>
                    <input type="radio" id="p1" name="1-1" value="1">
                    <label for="p1">Sim</label>
                    <input type="radio" id="p2" name="1-1" value="0">
                    <label for="p2">Não</label><br><br>
                </div>
                
                <div>
                    <label for="" class="form-label">2) O prestador de serviço foi cordial no atendimento?</label><br>
                    <input type="radio" id="p3" name="1-2" value="1">
                    <label for="p3">Sim</label>
                    <input type="radio" id="p4" name="1-2" value="0">
                    <label for="p4">Não</label><br><br>
                </div>
                    
                <div>
                    <label for="" class="form-label">3) Qual o grau de satisfação com a qualidade do serviço?</label><br>
                    <input type="radio" id="p5" name="1-3" value="0">
                    <label for="p5">Ruim</label>
                    <input type="radio" id="p6" name="1-3" value="1">
                    <label for="p6">Bom</label>
                    <input type="radio" id="p7" name="1-3" value="2">
                    <label for="p7">Muito bom</label>
                    <input type="radio" id="p8" name="1-3" value="3">
                    <label for="p8">Excelente</label><br><br>
                </div>
                    
                <div>
                    <label for="" class="form-label">4) Qual a possibilidade de recomendar nossos serviços?</label><br>
                    <input type="radio" id="p9" name="1-4" value="0">
                    <label for="p9">Nunca</label>
                    <input type="radio" id="p10" name="1-4" value="1">
                    <label for="p10">Talvez</label>
                    <input type="radio" id="p11" name="1-4" value="2">
                    <label for="p11">Sempre</label>
                </div>
                <br>
                <div class="mb-3">     
                    <label for="obs">Utilize o campo abaixo para algo que deseja manifestar e que não foi contemplado no formulário acima:</label><br><br>
                    <textarea id="obs" name="obs" rows="4" cols="55" placeholder="Seu texto aqui...."></textarea>
                </div><br><br>
            <input class="btn btn-primary" type="submit" name="submit">
        </form>
    </div>
    <footer>
        © 2024 Sistema de Avaliação
    </footer>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php 
    if (!isset($_SESSION['logged_on']) || !$_SESSION['logged_on']){
        header('Location: /./do-zero/index.php');
        exit(); // Adicionado para evitar execução do código após redirecionamento
    }

    if(isset($_POST['submit'])){
        if (isset($_POST['1-1']) && isset($_POST['1-2']) && isset($_POST['1-3']) && isset($_POST['1-4'])){
            // Processamento do formulário aqui
            
            $user = $_SESSION['username'];
            $cpf = $_SESSION['cpf'];
            $telefone = $_SESSION['telefone'];
            $email = $_SESSION['email'];

            $resposta_1 = $_POST['1-1'];
            $resposta_2 = $_POST['1-2'];
            $resposta_3 = $_POST['1-3'];
            $resposta_4 = $_POST['1-4'];
            $obs = $_POST['obs'];

            $sql = "SELECT id FROM cliente WHERE cpf = '$cpf'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $id_user = $row['id'];
            } else {
                $colunas_login = "`nome`, `email`, `telefone`, `cpf`";
                $login = "INSERT INTO `cliente`($colunas_login) VALUES ('$user', '$email', '$telefone', '$cpf')";

                mysqli_query($conn, $login);
                $id_user = mysqli_insert_id($conn);
            }

            $observacao = filter_input(INPUT_POST, "obs", FILTER_SANITIZE_SPECIAL_CHARS);
        
            $colunas = '`id_cliente`, `data_hora`, `pergunta_1`, `pergunta_2`, `pergunta_3`, `pergunta_4`, `observacao`';
            $data_e_hora_atual = date("Y-m-d H:i:s");

            $request = "INSERT INTO `avaliacao`($colunas) VALUES ('$id_user', '$data_e_hora_atual', '$resposta_1', '$resposta_2', '$resposta_3', '$resposta_4', '$observacao')";

            mysqli_query($conn, $request);

            session_destroy();
            header('Location: /./do-zero/index.php');
            exit(); // Adicionado para evitar execução do código após redirecionamento
        }
    }

    mysqli_close($conn);
?>