<?php 
    include('db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responder Avaliação</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; 
            padding-top: 20px;
            margin: 0px;
            padding: 0px; 
        }
        .container {
            max-width: 600px; 
            margin: auto;
            background-color: #fff; 
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold; 
        }
        textarea {
            width: 100%; 
            height: 150px; 
            resize: none; 
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px; 
            margin-top: 10px; 
            background-color: #007bff; 
            color: white; 
            border: none; 
            cursor: pointer; 
            border-radius: 5px; 
        }
        input[type="submit"]:hover {
            background-color: #0056b3; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Responder Avaliação</h2>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
            <div class="mb-3">
                <label for="resposta">Resposta:</label>
                <textarea name="resposta" id="resposta" class="form-control"></textarea>
            </div>
            <input type="submit" name="submit">
        </form>
    </div>
</body>
</html>

<?php 
    if(isset($_POST['submit'])){
        $id_avaliacao = $_GET['id'];
        $resposta = "<strong>Resposta enviada em " . date("Y-m-d H:i:s") . "   </strong><br>" . $_POST['resposta'];

        $sql_update = "UPDATE avaliacao SET resposta = '$resposta' WHERE id = '$id_avaliacao'";
        mysqli_query($conn, $sql_update);

        header('Location: preview.php');
    }
    
    mysqli_close($conn);
?>