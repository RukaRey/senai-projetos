<?php 
    include('db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Avaliações</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 20px;
            color: #333;
            margin: 0px;
            padding: 0px;
        }
        .navbar-custom {
            background-color: #007bff; 
            color: white;
        }
        .navbar-custom .navbar-brand {
            color: white;
        }
        .table-custom {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .text-center {
            text-align: center;
        }
        footer {
            text-align: center;
            padding: 10px 0;
            font-size: 0.8rem;
            background-color: #f8f9fa;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="#">Sistema de Avaliação</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php
        $sql = "SELECT avaliacao.*, cliente.nome, cliente.email, cliente.telefone, cliente.cpf 
                FROM avaliacao
                INNER JOIN cliente ON avaliacao.id_cliente = cliente.id";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                // include('../files/php/resposta.php');
        ?>
        <div class="table-responsive">
            <table class="table table-custom table-bordered">
                    <tr>
                        <td ><p>Cliente: <?php echo $row["nome"] ?></p></td>
                        <td><p>CPF: <?php echo $row["cpf"] ?></p></td>
                        <td><p>Email: <?php echo $row["email"] ?></p></td>
                        <td><p>Telefone: <?php echo $row["telefone"] ?></p></td>
                     </tr>
                        <?php 
                            if ($row["pergunta_1"] == 1){
                                $resul_1 = "Sim";
                            }else{
                                $resul_1 = "Não";
                            }
                            if ($row["pergunta_2"] == 1){
                                $resul_2 = "Sim";
                            }else{
                                $resul_2 = "Não";
                            }
                            switch($row["pergunta_3"]){
                                case 0:
                                    $resul_3 = "Ruim";
                                    break;
                                case 1:
                                    $resul_3 = "Bom";
                                    break;
                                case 2:
                                    $resul_3 = "Muito bom";
                                    break;
                                case 3:
                                    $resul_3 = "Excelente";
                                    break;
                            }
                            switch($row["pergunta_4"]){
                                case 0:
                                    $resul_4 = "Nunca";
                                    break;
                                case 1:
                                    $resul_4 = "Talvez";
                                    break;
                                case 2:
                                    $resul_4 = "Sempre";
                                    break;
                            }
                            if(!empty($row["observacao"])){ 
                                $obs = $row["observacao"];
                            }else{
                                $obs = "Sem comentários.";
                            }
                        ?>
                    <tr >
                        <td ><p>Serviço concluído a tempo?</p></td>
                        <td  align="center"><p><?php echo $resul_1; ?></p></td>
                        <td ><p>Prestador foi cordeal?</p></td>
                        <td  align="center"><p><?php echo $resul_2; ?></p></td>
                    </tr>
                    <tr>
                        <td><p>Qualidade do serviço?</p></td>
                        <td align="center"><p><?php echo $resul_3; ?></p></td>
                        <td><p>Recomendaria o serviço?</p></td>
                        <td align="center"><p><?php echo $resul_4; ?></p></td>
                    </tr>
                    <tr>
                        <td colspan = "2"><p>Observação:</p></td>
                        <td colspan = "2" align="center"><p><?php echo $obs; ?></p></td>
                    </tr>
                    <tr>
                        <td colspan = "2"><p>Resposta:</p></td>
                        <td colspan = "2" align="center">
                            <?php 
                                if (empty($row['resposta'])){
                                    echo '<p>Resposta pendente.</p>';
                                    echo "<a href='resposta.php?id={$row['id']}'>Responder</a>";
                                } else{
                                    echo $row['resposta'];
                                }
                            ?>
                        </td>
                    </tr>
                </table>     
            </div>
                
            <?php
            }
        } else {
            echo "0 resultados";
        }
        ?>
    </div>
    <footer>
        © 2024 Sistema de Avaliação
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php
    mysqli_close($conn);
?>


