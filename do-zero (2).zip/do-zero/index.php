<?php 
    session_start();
    if (isset($_POST['submit'])){
        $_SESSION['username'] = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
        $_SESSION['cpf'] = $_POST['cpf'];
        $_SESSION['telefone'] = $_POST['telefone'];
        $_SESSION['email'] = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);

        $_SESSION['logged_on'] = true;

        header('Location: /./do-zero/files/php/avaliacao.php');
        exit; // Certifique-se de sair após redirecionar
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Avaliação</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            margin: 0px;
            padding: 0px;
        }
        .container {
            max-width: 500px;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .navbar-custom {
            background-color: #007bff; 
            padding: 1rem 1rem;
            
        }
        .navbar-custom .navbar-brand,
        .navbar-custom .nav-link {
            color: white;
        }
        .navbar-custom .nav-link:hover {
            color: #ccc;
        }

        .aaaa{
            margin-top: 75px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">Sistema de Avaliação</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="files/php/login_adm.php">Login Administrativo</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container aaaa">
        <h2 class="mb-3 text-center">Login - Avaliação</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="p-4 border rounded bg-white">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="John Doe" value="<?php if(isset($_SESSION['username'])) { echo $_SESSION['username']; } ?>" required>
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF:</label>
                <input type="text" class="form-control" id="cpf" name="cpf" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" placeholder="123.456.789-00" minlength="14" maxlength="14" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail:</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="example123@gmail.com" required>
            </div>
            <div class="mb-3">
                <label for="telefone" class="form-label">Telefone:</label>
                <input type="text" class="form-control" id="telefone" name="telefone" pattern="\([0-9]{2}\) [0-9]{4,5}-[0-9]{4}" placeholder="(00) 12345-6789" minlength="15" maxlength="15" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary" name="submit">Entrar</button>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
    <script>
        document.getElementById('cpf').addEventListener('input', function(e) {
            var cpf = e.target.value.replace(/\D/g, '');
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
            cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = cpf;
        });
    
        document.getElementById('telefone').addEventListener('input', function(e) {
            var tel = e.target.value.replace(/\D/g, '');
            tel = tel.replace(/(\d{2})(\d)/, '($1) $2');
            tel = tel.replace(/(\d{4,5})(\d{4})$/, '$1-$2');
            e.target.value = tel;
        });
    </script>
</body>
</html>
