<?php 
    include('db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <p>Para melhor atendê-lo, forneça as seguintes informações:</p>
        <label for="">Nome</label>
        <input type="text" id="nome" name="nome" placeholder="John Doe" value="<?php if(isset($_SESSION['username'])) ?>"  required>

        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" placeholder="123.456.789-00" minlength="14" maxlength="14" required>
  
        <label for="">E-mail</label>
        <input type="email" name="email" id="email" placeholder="example123@gmail.com" required>

        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" pattern="\([0-9]{2}\) [0-9]{4,5}-[0-9]{4}" placeholder="(00) 12345-6789" minlength="15" maxlength="15" required>

        <input type="submit" name="submit">
    </form>
    
</body>
</html>

<script>
    document.getElementById('cpf').addEventListener('input', function(e) {
        var cpf = e.target.value.replace(/\D/g, ''); // Remove caracteres não numéricos
        cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Adiciona o primeiro ponto
        cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Adiciona o segundo ponto
        cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); // Adiciona o traço
        e.target.value = cpf; // Define o valor formatado no campo
    });

    document.getElementById('telefone').addEventListener('input', function(e) {
        var tel = e.target.value.replace(/\D/g, ''); // Remove caracteres não numéricos
        tel = tel.replace(/(\d{2})(\d)/, '($1) $2'); // Adiciona o código de área
        tel = tel.replace(/(\d{4,5})(\d{4})$/, '$1-$2'); // Adiciona o traço
        e.target.value = tel; // Define o valor formatado no campo
    });
</script>

<?php 
    if (isset($_POST['submit'])){
        $_SESSION['username'] = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
        $_SESSION['cpf'] = $_POST['cpf'];
        $_SESSION['telefone'] = $_POST['telefone'];
        $_SESSION['email'] = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);

        $_SESSION['logged_on'] = true;

        header('Location: /./FRAMEWORK/do-zero/index.php');
    }
?>