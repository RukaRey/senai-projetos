<?php 
    include('files/php/db.php');
    $conn = createConn('localhost','root','','sistema_avaliacao');
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
        <label for="">1) O serviço foi concluído no prazo?</label><br>
        <input type="radio" id="1-1" name="1-1" value="1">
        <label for="1-1">Sim</label>
        <input type="radio" id="1-1" name="1-1" value="0">
        <label for="1-1">Não</label><br><br>

        <label for="">2) O prestador de serviço foi cordial no atendimento?</label><br>
        <input type="radio" id="1-2" name="1-2" value="1">
        <label for="1-2">Sim</label>
        <input type="radio" id="1-2" name="1-2" value="0">
        <label for="1-2">Não</label><br><br>

        <label for="">3) Qual o grau de satisfação com a qualidade do serviço?</label><br>
        <input type="radio" id="1-3" name="1-3" value="0">
        <label for="1-3">Ruim</label>
        <input type="radio" id="1-3" name="1-3" value="1">
        <label for="1-3">Bom</label><br>
        <input type="radio" id="1-3" name="1-3" value="2">
        <label for="1-3">Muito bom</label>
        <input type="radio" id="1-3" name="1-3" value="3">
        <label for="1-3">Excelente</label><br><br>

        <label for="">4) Qual a possibilidade de recomendar nossos serviços?</label><br>
        <input type="radio" id="1-4" name="1-4" value="0">
        <label for="1-4">Nunca</label>
        <input type="radio" id="1-4" name="1-4" value="1">
        <label for="1-4">Talvez</label><br>
        <input type="radio" id="1-4" name="1-4" value="2">
        <label for="1-4">Sempre</label><br><br>

        <label for="">Utilize o campo abaixo para algo que deseja manifestar e que não foi contemplado no formulário acima:</label><br>
        <input type="text" id="obs" name="obs">

        <input type="submit" name="submit">
    </form>
</body>
</html>

<?php 
    // if (isset($_SESSION['logged_on']) && $_SESSION['logged_on'] == true){
    //     header('Location: files/php/login.php');

    // }

    if(isset($_POST['submit'])){
        if (isset($_POST['1-1']) && isset($_POST['1-2']) && isset($_POST['1-3']) && isset($_POST['1-4'])){
            $resposta_1 = $_POST['1-1'];
            $resposta_2 = $_POST['1-2'];
            $resposta_3 = $_POST['1-3'];
            $resposta_4 = $_POST['1-4'];

            $user = $_SESSION['username'];
            $cpf = $_SESSION['cpf'];
            $telefone = $_SESSION['telefone'];
            $email = $_SESSION['email'];

            $observacao = filter_input(INPUT_POST, "obs", FILTER_SANITIZE_SPECIAL_CHARS);
        
            $colunas = '`id_cliente`, `data_hora`, `pergunta_1`, `pergunta_2`, `pergunta_3`, `pergunta_4`, `observacao`';
            $colunas_login = "`nome`, `email`, `telefone`, `cpf`";

            $login = "INSERT INTO `cliente`($colunas_login) VALUES ('$user', '$email', '$telefone', '$cpf')";
            $conn->query($login);
            $ultimo_id = mysqli_insert_id($conn);

            $data_e_hora_atual = date("Y-m-d H:i:s");

            $request = "INSERT INTO `avaliacao`($colunas) VALUES ('$ultimo_id', '$data_e_hora_atual', '$resposta_1', '$resposta_2', '$resposta_3', '$resposta_4', '$observacao')";

            $conn->query($request);

            header('Location: files/php/login.php');
        }
    }

    $conn->close();
?>